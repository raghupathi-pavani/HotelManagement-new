package com.org.hbms.service;

import java.sql.SQLException;

import com.org.hbms.bean.HBMSBookingBean;
import com.org.hbms.bean.HBMSHotelBean;
import com.org.hbms.bean.HBMSRoomBean;
import com.org.hbms.bean.HBMSUserBean;
import com.org.hbms.dao.HBMSDaoImpl;
import com.org.hbms.dao.IHBMSDao;
import com.org.hbms.exception.HBMSException;

public class HBMSserviceImpl implements IHBMSservice{

	@Override
	public int registerUser(HBMSUserBean b) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.registerUser(b);		
	}

	@Override
	public boolean validateUserLogin(String username, String password) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.validateUserLogin(username,password);
	}

	@Override
	public StringBuilder getHotelDetails() throws HBMSException{
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getHotelDetails();
	}

	@Override
	public HBMSUserBean getUserDetails(String username, String password) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getUserDetails(username,password);
	}

	@Override
	public boolean isValidPassword(String rPassword) {
		int length=rPassword.length();
		if(length>7 && length<0)
		{
			return false;
		}
		return true;
	}

	@Override
	public StringBuilder displayRooms(String hotel_id) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.displayRooms(hotel_id);
	}

	@Override
	public boolean isValidHotelId(String hotel_id) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.isValidHotelId(hotel_id);
	}

	@Override
	public boolean validateAdminLogin(String username, String password) {
		if(username.equals("admin") && password.equals("admin"))
		{
			return true;
		}
		return false;
	}

	@Override
	public void addHotelDetails(HBMSHotelBean hotel) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.addHotelDetails(hotel);
	}

	@Override
	public void deleteHotel(String hotelId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.deleteHotel(hotelId);
	}

	@Override
	public void deleteHotelRooms(String hotelId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.deleteHotelRooms(hotelId);
	}

	@Override
	public void addRoomDetails(HBMSRoomBean room) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.addRoomDetails(room);
	}

	@Override
	public boolean isValidRoomId(String roomId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.isValidRoomId(roomId);
	}

	@Override
	public void deleteRoom(String roomId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.deleteRoom(roomId);
		
	}

	@Override
	public float getRoomAmount(String roomId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getRoomAmount(roomId);
	}

	@Override
	public String addBookingDetails(HBMSBookingBean booking) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.addBookingDetails(booking);
	}

}
