package com.org.hbms.pi;

import java.util.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import javax.sql.rowset.serial.SerialArray;

import com.org.hbms.bean.HBMSBookingBean;
import com.org.hbms.bean.HBMSHotelBean;
import com.org.hbms.bean.HBMSRoomBean;
import com.org.hbms.bean.HBMSUserBean;
import com.org.hbms.exception.HBMSException;
import com.org.hbms.service.HBMSserviceImpl;
import com.org.hbms.service.IHBMSservice;

public final class HBMSMain {
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) throws HBMSException, SQLException {
		String rUserName,rPassword,rUserId,rMobileNo,rPhone,rRole,rEmail,rAddress;
		
		HBMSUserBean b=new HBMSUserBean();
		IHBMSservice s1=new HBMSserviceImpl();
		System.out.println("Welcome to hotel bookings\n");
		int ch;
		String username,password;
		do
		{
			System.out.println("enter your choice");
			System.out.println("1.user login \n 2.admin login \n 3.user registration \n 4.exit");
			ch=sc.nextInt();
			if(ch==1)
			{
				System.out.println("please enter login credentials");
				System.out.println("user name:");
				username=sc.next();
				System.out.println("enter password:");
				password=sc.next();
				if(s1.validateUserLogin(username,password))
				{
					System.out.println("logged in sucessfully");
					HBMSUserBean user=s1.getUserDetails(username,password);
					System.out.println("hotels and their descriptions");
					displayHotels(user);			
				}
				else
				{
					System.out.println("invalid credentials");
				}
			}
			else if(ch==2)
			{
				System.out.println("please enter login credentials");
				System.out.println("username:");
				username=sc.next();
				System.out.println("password:");
				password=sc.next();
				if(s1.validateAdminLogin(username,password))
				{
					displayAdminMenu();
				}
				else
				{
					System.out.println("invalid credentials");
				}
			}
			else if(ch==3)
			{
				System.out.println("fill out the following fields\n");
				System.out.println("enter password:");
				rPassword=sc.next();
				while(true)
				{
					if(s1.isValidPassword(rPassword))
					{
						break;
					}
					else
					{
						System.out.println("enter valid password:");
						rPassword=sc.next();
					}
				}
				System.out.println("enter user name:");
				rUserName=sc.next();
				System.out.println("enter mobile number:");
				rMobileNo=sc.next();
				System.out.println("enter phone number");
				rPhone=sc.next();
				System.out.println("enter your address:");
				rAddress=sc.next();
				System.out.println("enter your mail id:");
				rEmail=sc.next();
				b.setPassword(rPassword);
				b.setUserName(rUserName);
				b.setMobileNo(rMobileNo);
				b.setPhone(rPhone);
				b.setRole("user");
				b.setAddress(rAddress);
				b.setEmail(rEmail);
				int Id=s1.registerUser(b);
				String userId=Integer.toString(Id);
				b.setUserId(userId);
				System.out.println("you have registeres sucessfully with registration ID:"+b.getUserId());
			}
			else if(ch==4)
			{
				break;
			}
			else
			{
				System.out.println("please enter valid choice");
			}
		}while(ch!=4);
	}

	private static void displayAdminMenu() {
		int op,choice;
		String hotelId,city,address,email,fax,phoneNo1,phoneNo2,avgRatePerNight,rating,description,hotelName,roomId,roomNo,roomType,availability;
		float perNightRent;
		IHBMSservice s1=new HBMSserviceImpl();
		HBMSHotelBean hotel=null;
		HBMSRoomBean room=null;
		do
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("enter your choice");
			System.out.println("1.hotel management\n2.room management\n3.generate report\n4.exit");
			choice=sc.nextInt();
			if(choice==1)
			{
				do
				{
					System.out.println("enter operation to perform");
					System.out.println("1.add hotel\n2.delete hotel\n3.exit");
					op=sc.nextInt();
					if(op==1)
					{
						hotel=new HBMSHotelBean();
						System.out.println("fill the following details");
						System.out.println("enter hotel ID");
						hotelId=sc.next();
						System.out.println("city name");
						city=sc.next();
						System.out.println("hotel name");
						hotelName=sc.next();
						System.out.println("hotel address");
						address=sc.next();
						System.out.println("hotel description");
						description=sc.next();
						System.out.println("average rate per night");
						avgRatePerNight=sc.next();
						System.out.println("phone number 1");
						phoneNo1=sc.next();
						System.out.println("phone number 2");
						phoneNo2=sc.next();
						System.out.println("rating");
						rating=sc.next();
						System.out.println("email");
						email=sc.next();
						System.out.println("fax");
						fax=sc.next();
						hotel.setHotelId(hotelId);
						hotel.setCity(city);
						hotel.setHotelName(hotelName);
						hotel.setAddress(address);
						hotel.setDescription(description);
						hotel.setAvgRatePerNight(avgRatePerNight);
						hotel.setPhoneNo1(phoneNo1);
						hotel.setPhoneNo2(phoneNo2);
						hotel.setRating(rating);
						hotel.setEmail(email);
						hotel.setFax(fax);
						try
						{
							s1.addHotelDetails(hotel);
						} 
						catch (HBMSException e)
						{
							System.out.println(e.getMessage());
						}
					}
					else if(op==2)
					{
						System.out.println("enter hotel Id to delete");
						hotelId=sc.next();
						try 
						{
							if(s1.isValidHotelId(hotelId))
							{
								s1.deleteHotel(hotelId);
								s1.deleteHotelRooms(hotelId);
							}
							else
							{
								System.out.println("please enter valid hotelId");
							}
						}
						catch (HBMSException e) {
							System.out.println(e.getMessage());
						}
					}
					else if(op==3)
					{
						break;
					}
					else
					{
						System.out.println("please enter valid choice");
					}
				}while(op!=3);
			}
			else if(choice==2)
			{
				do
				{
					System.out.println("enter operation to perform");
					System.out.println("1.add room\n2.delete room\n3.exit");
					op=sc.nextInt();
					if(op==1)
					{
						room=new HBMSRoomBean();
						System.out.println("enter hotelId");
						hotelId=sc.next();
						try 
						{
							if(s1.isValidHotelId(hotelId))
							{
								room.setHotelId(hotelId);
								System.out.println("enter roomId");
								roomId=sc.next();
								room.setRoomId(roomId);
								System.out.println("enter room number");
								roomNo=sc.next();
								room.setRoomNo(roomNo);
								int ch;
								do
								{
									System.out.println("select room type: \n1.Standard non A/C room\n2.Standard A/C room\n3.Executive A/C room\n4.Deluxe A/C room ");
									ch=sc.nextInt();
									if(ch==1)
									{
										roomType="Standard non A/C room";
										break;
									}
									else if(ch==2)
									{
										roomType="Standard A/C room";
										break;
									}
									else if(ch==3)
									{
										roomType="Executive A/C room";
										break;
									}
									else if(ch==4)
									{
										roomType="Deluxe A/C room";
										break;
									}
									else
									{
										System.out.println("please select valid option");
									}
								}while(true);
								room.setRoomType(roomType);
								System.out.println("enter room cost per night");
								perNightRent=sc.nextFloat();
								room.setPerNightRate(perNightRent);
								do
								{
									System.out.println("room availability\n1.true\n2.false");
									ch=sc.nextInt();
									if(ch==1)
									{
										availability="true";
										break;
									}
									else if(ch==2)
									{
										availability="false";
										break;
									}
									else
									{
										System.out.println("please select valid choice");
									}
								}while(true);
								room.setAvailability(availability);
								s1.addRoomDetails(room);
							}
						} 
						catch (HBMSException e)
						{
							System.out.println(e.getMessage());
						}
					}
					else if(op==2)
					{
						System.out.println("enter room Id to delete");
						roomId=sc.next();
						try 
						{
							if(s1.isValidRoomId(roomId))
							{
								s1.deleteRoom(roomId);
							}
							else
							{
								System.out.println("please enter valid roomId");
							}
						}
						catch (HBMSException e) {
							System.out.println(e.getMessage());
						}
					}
					else if(op==3)
					{
						break;
					}
					else
					{
						System.out.println("please enter valid choice");
					}
				}while(op!=3);
			}
			else if(choice==3)
			{
				System.out.println("select which report to generate");
				System.out.println("1.View List of Hotels\n2.View Bookings of specific hotel\n3.View guest list of specific hotel\n4.View bookings for specified date\n5.exit");
				op=sc.nextInt();
				if(op==1)
				{
					System.out.println("list of hotels :");
					StringBuilder hotelDetails;
					try 
					{
						hotelDetails = s1.getHotelDetails();
						System.out.println(hotelDetails);
					} 
					catch (HBMSException e)
					{
						System.out.println(e.getMessage());
					}
					
				}
				else if(op==2)
				{
					System.out.println("enter hotelId-to get bookings");
					hotelId=sc.next();
					try
					{
						if(s1.isValidHotelId(hotelId))
						{
							
						}
						else
						{
							System.out.println("invalid hotel Id");
						}
					} 
					catch (HBMSException e)
					{
						System.out.println(e.getMessage());
					}
				}
				else if(op==3)
				{
					System.out.println("enter hotel Id-to view guest list");
					hotelId=sc.next();
					try
					{
						if(s1.isValidHotelId(hotelId))
						{
							
						}
						else
						{
							System.out.println("invalid hotel Id");
						}
					} 
					catch (HBMSException e)
					{
						System.out.println(e.getMessage());
					}
				}
				else if(op==4)
				{
					System.out.println("enter date to view bookings of that date");
					Date d;
					
				}
				else if(op==5)
				{
					break;
				}
				else
				{
					System.out.println("please select valid choice");
				}
			}
			else if(choice==4)
			{
				break;
			}
			else
			{
				System.out.println("please enter valid choice");
			}
		}while(choice!=3);
		
	}

	private static void displayHotels(HBMSUserBean user) {
		IHBMSservice s1=new HBMSserviceImpl();
		HBMSBookingBean booking=null;
		Scanner sc=new Scanner(System.in);
		String bookingId,date1,date2;
		int noOfAdults,noOfChildren;
		float amount;
		String expectedPattern = "dd/MM/yyyy";
	    SimpleDateFormat formatter = new SimpleDateFormat(expectedPattern);
		if(user.getRole().equals("user"))
		{
			System.out.println("select hotel from the below list");
			try
			{
				StringBuilder hotelDetails=s1.getHotelDetails();
				System.out.println(hotelDetails);
				if(hotelDetails.length()>0)
				{
					System.out.println("enter hotel id to view rooms");
					String hotel_id=sc.next();
					while(true)
					{
						if(s1.isValidHotelId(hotel_id))
						{
							StringBuilder roomDetails=s1.displayRooms(hotel_id);
							System.out.println("select room from the below list");
							System.out.println(roomDetails);
							System.out.println("enter room id to go to booking page");
							String roomId=sc.next();
							if(s1.isValidRoomId(roomId))
							{
								booking=new HBMSBookingBean();
								booking.setUserId(user.getUserId());
								booking.setRoomId(roomId);
								System.out.println("enter booking from date(format-dd/mm/yyyy)");
								date1=sc.next();
								booking.setBokkedFrom(formatter.parse(date1));
								System.out.println("enter booking to date(format-dd/mm/yyyy)");
								date2=sc.next();
								booking.setBookedTo(formatter.parse(date2));
								System.out.println("enter number of adults");
								noOfAdults=sc.nextInt();
								booking.setNoOfAdults(noOfAdults);
								System.out.println("enter number of children");
								noOfChildren=sc.nextInt();
								booking.setNoOfChildren(noOfChildren);
								amount=s1.getRoomAmount(roomId);
								int diff=(int) ((booking.getBookedTo().getTime()-booking.getBokkedFrom().getTime()) / (1000 * 60 * 60 * 24));
								amount=amount*diff;
								booking.setAmount(amount);
								String bookingID=s1.addBookingDetails(booking);
								booking.setBookingId(bookingID);
								System.out.println("your booking is sucessfull-with booking id "+bookingID);
							}
							break;
						}
					}
				}
			}
			catch (HBMSException e)
			{
					System.out.println(e.getMessage());
			} 
			catch (ParseException e) 
			{
				System.out.println("error while converting date");
			}
		}
		else
		{
			
		}
		
	}

}
