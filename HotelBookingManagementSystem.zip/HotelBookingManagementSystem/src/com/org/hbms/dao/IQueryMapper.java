package com.org.hbms.dao;

public interface IQueryMapper {
	String userRegisterQuery="insert into Users values(?,?,?,?,?,?,?,?)";
	String userValidQuery="select count(*) from users where user_name=? and password=?";
	String hotelDetailsQuery="select * from hotel";
	String userIdQuery = "select user_id_seq.nextval from dual";
	String getRoleQuery = "select * from Users where user_name=? and password=?";
	String displayRoomQuery = "select * from roomdetails where hotel_Id=?";
	String validHotelQuery = "select count(*) from hotel where hotel_id=?";
	String hotelAddQuery = "insert into hotel values(?,?,?,?,?,?,?,?,?,?,?)";
	String deleteHotelQuery = "delete from hotel where hotel_id=?";
	String deleteHotelRoomQuery = "delete from RoomDetails where hotel_id=?";
	String addRoomDetailsQuery = "insert into roomDetails values(?,?,?,?,?,?,'')";
	String validRoomQuery = "select count(*) from roomDetails where room_id=?";
	String deleteRoomQuery = "delete from RoomDetails where room_id=?";
	String getRoomAmountQuery = "select per_night_rate from roomdetails where room_id=?";
	String addBookingDetailsQuery ="insert into bookingdetails values(?,?,?,?,?,?,?,?)";
	String bookingIdQuery="select booking_id_seq.nextval from dual";
}